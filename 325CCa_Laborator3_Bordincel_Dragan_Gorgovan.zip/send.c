#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>

#include "lib.h"

#define HOST "127.0.0.1"
#define PORT 10000

int main(int argc, char *argv[])
{
	msg t;
	pkt p;
	int i, res;
	int WINDOW_SIZE;

	WINDOW_SIZE = (atoi(argv[1]) * 1000) / (sizeof(msg) * 8);

	printf("%d\n", WINDOW_SIZE);

	printf("[SENDER] Starting.\n");	
	init(HOST, PORT);

	/* printf("[SENDER]: BDP=%d\n", atoi(argv[1])); */
	
	for (i = 0; i < WINDOW_SIZE - 1; i++) {
		memset(&t, 0, sizeof(msg));
		
		sprintf(p.actual_payload, "%s", "Ana are mere");
		/* gonna send an empty msg */
		//t.len = strlen(t.payload);
		p.checksum = strlen(p.actual_payload);

		memcpy(t.payload, p.actual_payload, sizeof(pkt));
		/* send msg */
		res = send_message(&t);
		if (res < 0) {
			perror("[SENDER] Send error. Exiting.\n");
			return -1;
		}
	}

	for (i = WINDOW_SIZE - 1; i < COUNT; i++) {
		/* cleanup msg */ 
		memset(&t, 0, sizeof(msg));
		
		sprintf(p.actual_payload, "%s", "Ana are mere");
		/* gonna send an empty msg */
		//t.len = strlen(t.payload);
		p.checksum = strlen(p.actual_payload);

		memcpy(t.payload, p.actual_payload, sizeof(pkt));
		/* send msg */
		res = send_message(&t);
		if (res < 0) {
			perror("[SENDER] Send error. Exiting.\n");
			return -1;
		}
		
		/* wait for ACK */
		res = recv_message(&t);
		if (res < 0) {
			perror("[SENDER] Receive error. Exiting.\n");
			return -1;
		}
	}

	for (i = 0; i < WINDOW_SIZE - 1; i++) {
		/* wait for ACK */
		res = recv_message(&t);
		if (res < 0) {
			perror("[SENDER] Receive error. Exiting.\n");
			return -1;
		}
	}

	printf("[SENDER] Job done, all sent.\n");
		
	return 0;
}
